package testCase;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.testng.TestNG;
import org.testng.annotations.Test;


public class TestRunner {


	//static UtilitiesForApplication utils = new UtilitiesForApplication();
	static String env;
	static String wireMockValue;
	
	static String realApiValue;
	
	static StubServerMain ss = new StubServerMain();
	
	public static void main(String[] args) throws IOException {
		TestRunner.start();
	}

	public static void start() throws IOException {
		
		
			Properties props = new Properties();
			
			FileInputStream inStream;
				String path = System.getProperty("user.dir");
				inStream = new FileInputStream(path+"\\config.properties");
				props.load(inStream);
				inStream.close();			
				wireMockValue = props.getProperty("WireMock");
				//System.out.println(wireMockValue);				
				realApiValue = props.getProperty("RealApi");
				if(wireMockValue.equalsIgnoreCase("true"))
					StubServerMain.startStub();
				else
				{
					RealApi.getRealApiRequest();
				}
				
			}
	
	
}

