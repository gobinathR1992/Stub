package testCase;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class RealApi {
	

	public static void getRealApiRequest()
	{
				System.out.println("Wiremock is off --> Executing Real API Env");
			
				String realAPI = TestRunner.realApiValue;
				
				RestAssured.baseURI = realAPI;
				Response response = RestAssured.given().get(); 
					//Print the Status Code
					System.out.println(response.getStatusCode());
					
					//Content Type
					String contentType = response.getContentType();
					System.out.println(contentType);
					
				}
}
